# Авторы, оригиналы и происхождение CarrierSIM-iOS

**ОРИГИНАЛ CARRIERSIM ВЗЯТ ИЗ [IOS-BUNDLES/CARRIERSIM](https://github.com/ios-bundles/CarrierSIM).**

Этот репозиторий предназначен для экспериментального iOS-порта CarrierSIM. Он не является официальным выпуском перечисленных ниже проектов. Авторство оригинальных программ, методов, библиотек и ресурсов принадлежит их авторам; авторство порта не заменяет эти сведения.

## Исходная программа изменения профиля оператора

**CarrierSIM — [ios-bundles/CarrierSIM](https://github.com/ios-bundles/CarrierSIM).** В истории оригинального репозитория указан Владимир Белый / Vladimir Bely, [@vlw](https://github.com/vlw), а также другие участники проекта.

Непосредственный входной материал порта — предоставленный пользователем архив `CarrierSIM-v4-macOS-Windows 2.zip`, а не автоматически обновляемая ветка оригинала.

- [`carrier.py`](https://github.com/ios-bundles/CarrierSIM/blob/master/carrier.py) — исходный скрипт изменения привязок SIM к профилям оператора. Его логика послужила основой специализированных операций iOS-порта.
- [`bundle.yaml`](https://github.com/ios-bundles/CarrierSIM/blob/master/bundle.yaml) — исходный редактируемый файл выбора профилей. Копия из пользовательского архива использована в `Resources/bundle.yaml`.
- [`assets.zip`](https://github.com/ios-bundles/CarrierSIM/blob/master/assets.zip) — источник упакованных ресурсов IPCC, взятых из пользовательского архива без изменения.
- [`launch.py`](https://github.com/ios-bundles/CarrierSIM/blob/master/launch.py), [README](https://github.com/ios-bundles/CarrierSIM/blob/master/README.md) и [техническая инструкция](https://github.com/ios-bundles/CarrierSIM/blob/master/README.txt) — части исходного настольного комплекта. Настольный Python-лаунчер не используется в iOS-приложении.
- [`LICENSE-AirLift.txt`](https://github.com/ios-bundles/CarrierSIM/blob/master/LICENSE-AirLift.txt) — уведомление о лицензии AirLift из оригинального комплекта. Оно не должно автоматически трактоваться как отдельная лицензия на все файлы CarrierSIM.

SHA-256 исходного архива: `e60f24a31c13632f04b88fe3b0653b793181dead8dcfaefa8e91bea792d404b9`.

Ссылки на `master` позволяют найти оригиналы, но не означают, что текущая версия каждого файла побайтно совпадает с архивом v4. При несовпадении первичным входным материалом этой сборки остаётся пользовательский архив; его нельзя незаметно заменять новой версией.

## Нативная основа и протоколы

| Проект | Автор / источник | Роль в порте | Зафиксированная ревизия |
|---|---|---|---|
| [AirLift](https://github.com/0xjohnnydev/airlift) | Johnny Franks / 0xjohnnydev | Исходный метод AirTraffic, используемый через CarrierSIM и AirCard; исходное уведомление MIT сохраняется. | Отдельный SHA в исходном манифесте порта не записан. |
| [AirCard-iOS](https://github.com/Mak5er/AirCard-iOS) | Mak5er и авторы исходных компонентов | Нативный транспорт, основа сопряжения и мост Grappa. Унаследованный текст MIT содержит copyright Johnny Franks; это уведомление нельзя заменять именем автора порта. | `097a058c984ffc33ccb697b9dfe8058be3e86244` |
| [idevice](https://github.com/jkcoxson/idevice) | Jackson Coxson и участники проекта | Реализация протоколов и служб iOS; vendored-копия с унаследованными и локальными изменениями. | `7bd551c16c6dd2e058740d85a2d9399a51a776e9` |
| [LocalDevVPN](https://github.com/jkcoxson/LocalDevVPN) | SideStore Team; происхождение StosVPN / Stossy11 отмечено в уведомлениях комплекта | Основа локального VPN, адаптированная на Objective-C; не официальный выпуск LocalDevVPN. | `af3fd697803ada4ac2b8d518358f5ab0a534844c` |
| [StikPair](https://github.com/StikDebug/StikPair) | StikDebug и участники проекта | Совместимость с форматом файлов сопряжения и изучение протокола. Приложение и интерфейс StikPair не копировались и не включены в IPA. | `d9661c505130a7b710225fb8ed61128527b46c7e` |

Ревизии и описание использования перенесены из `SOURCE-PROVENANCE.json` исходного комплекта. Это указание происхождения, а не утверждение, что все перечисленные проекты написаны автором CarrierSIM-iOS.

## Подпись приложения в версии 1.2

Используются опубликованные без изменений `isideload-apple-codesign` 0.29.11 и `isideload-cryptographic-message-syntax` 0.31.1, а также их транзитивные библиотеки `isideload`. Это форки Nicholas Sharp (nab138) компонентов Gregory Szorc / [apple-platform-rs](https://github.com/indygreg/apple-platform-rs): [isideload-apple-platform-rs](https://github.com/nab138/isideload-apple-platform-rs) и [isideload-cryptography-rs](https://github.com/nab138/isideload-cryptography-rs). Эти библиотеки используются в [SideInstaller](https://github.com/FrizzleM/SideInstaller). Версии зафиксированы в `CarrierSIM-iOS/rust-core/Cargo.lock`; исходные уведомления MPL-2.0 включены в `Licenses/THIRD-PARTY-RUST.txt` и оба IPA. Полный Apple Account/anisette-механизм SideInstaller в CarrierSIM не перенесён.

## Заголовки, зависимости, ресурсы и инструменты

- [libplist](https://github.com/libimobiledevice/libplist): используемые заголовки и их оригинальные copyright-уведомления Nikias Bassen и Jonathan Beck; условия LGPL-2.1-or-later для соответствующих заголовков сохранены отдельно.
- [plist_ffi](https://github.com/jkcoxson/plist_ffi): Rust-совместимая реализация, указанная в уведомлении о заголовках. Это не основание приписывать всем компонентам одинаковую лицензию.
- Прямые и транзитивные Rust-зависимости фиксируются в `rust-core/Cargo.lock`; перечень их лицензионных уведомлений входит в `Licenses/THIRD-PARTY-RUST.txt` исходного комплекта. Эти уведомления должны распространяться вместе с исходниками и сборками, а не заменяться одной ссылкой на Cargo.
- IPCC-ресурсы происходят из исходного CarrierSIM и пакетов Apple/операторов. Они не объявляются собственными ресурсами автора порта и не перелицензируются автоматически по MIT. Исходные адреса Apple приведены в оригинальном `README.txt`.
- [Theos SDKs](https://github.com/theos/sdks), [Procursus ldid](https://github.com/ProcursusTeam/ldid), [LLVM](https://github.com/llvm/llvm-project), [Rust](https://github.com/rust-lang/rust): инструменты/материалы сборки. Apple SDK не включён в архив исходников и не объявляется собственностью автора порта; конкретные версии и контрольные суммы записаны в `scripts/linux-toolchain.json`.

## Что добавлено в iOS-порте

Русский UIKit-интерфейс, интеграция сопряжения и локального подключения, специализированные операции CarrierSIM на Rust, проверка результата, восстановление прерванных операций, скрипты упаковки IPA и проверки. Порт был подготовлен с помощью ИИ. Отдельные адаптированные части сохраняют авторство и лицензионные условия оригиналов.

Работоспособность на физическом iPhone не подтверждена тестом этой сборки. Указание источников не означает одобрения или поддержки этого порта авторами оригинальных проектов.
